//
//  File.swift
//  OnMyFeet
//
//  Created by apple on 16/3/2.
//  Copyright © 2016年 OnMyFeet Group. All rights reserved.
//

import UIKit
import CoreData

class GoalDataManager: NSObject, NSFetchedResultsControllerDelegate {
    var goal: Goal?
    var activity: Activity?
    var progress: ActivityProgress?
    var goals = [Goal]()
    var activities = [Activity]()
    var progresses = [ActivityProgress]()
    var actGoalRelate: NSMutableSet?
    var progressActRelate: NSMutableSet?
    var fetchResultController: NSFetchedResultsController!
    
    func save(context: NSManagedObjectContext) {
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
    
    func insertGoalData(context: NSManagedObjectContext, picture: UIImage, question:String, example: String, answer: String) {
        goal = NSEntityDescription.insertNewObjectForEntityForName("Goal", inManagedObjectContext: context) as? Goal
        goal!.picture = UIImageJPEGRepresentation(picture, 1.0)!
        goal!.question = question
        goal!.example = example
        goal!.answer = answer
    }
    
    func insertActivityData (context: NSManagedObjectContext, name: String, status: Float) -> Activity {
        activity = NSEntityDescription.insertNewObjectForEntityForName("Activity", inManagedObjectContext: context) as? Activity
        activity!.name = name
        activity!.status = status
        return activity!
    }
    
    func insertProgressData (context: NSManagedObjectContext, date: String, status: Float) -> ActivityProgress {
        progress = NSEntityDescription.insertNewObjectForEntityForName("ActivityProgress", inManagedObjectContext: context) as? ActivityProgress
        progress!.date = date
        progress!.status = status
        return progress!
    }
    
    func insertActGoalRelation (theGoal: Goal, theAct: Activity) {
        actGoalRelate = theGoal.mutableSetValueForKey("activities")
        actGoalRelate?.addObject(theAct)
    }
    
    func insertProgressActRelation (theAct: Activity, theProgress: ActivityProgress) {
        progressActRelate = theAct.mutableSetValueForKey("activityProgresses")
        progressActRelate?.addObject(theProgress)
    }
    
    func fetchGoals() -> [Goal]? {
        let fetchRequest = NSFetchRequest (entityName: "Goal")
        let sortDescriptor = NSSortDescriptor (key: "question", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            fetchResultController = NSFetchedResultsController (fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            do {
                try fetchResultController.performFetch()
                goals = fetchResultController.fetchedObjects as! [Goal]
            }catch {
                print(error)
            }
        }
        return goals
    }
    
    func fetchActivities() -> [Activity]? {
        let fetchRequest = NSFetchRequest (entityName: "Activity")
        let sortDescriptor = NSSortDescriptor (key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            fetchResultController = NSFetchedResultsController (fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultController.delegate = self
            do {
                try fetchResultController.performFetch()
                activities = fetchResultController.fetchedObjects as! [Activity]
            }catch {
                print(error)
            }
        }
        return activities
    }
    
    func predicateFetchGoal(theExample: String) -> Goal {
        if let appDel = UIApplication.sharedApplication().delegate as? AppDelegate {
            let managedObjectContext = appDel.managedObjectContext
            let fetchRequest = NSFetchRequest(entityName: "Goal")
            fetchRequest.predicate = NSPredicate(format: "example == %@", theExample)
            
            do {
                let result = try managedObjectContext.executeFetchRequest(fetchRequest) as! [Goal]
                goal = result[0]
            }
            catch {
                print(error)
            }
        }
        return goal!
    }
    
    func predicateFetchActivity(context: NSManagedObjectContext, theName: String) -> Activity {
        let fetchRequest = NSFetchRequest(entityName: "Activity")
        fetchRequest.predicate = NSPredicate(format: "name == %@", theName)
        
        do {
            let result = try context.executeFetchRequest(fetchRequest) as! [Activity]
            if (result.count == 0) {
                activity = insertActivityData(context, name: theName, status: 0)
            }
            else {
                activity = result[0]
            }
        }
        catch {
            print(error)
        }
        return activity!
    }
    
    func executeProgressUpdate(context: NSManagedObjectContext, theAct: Activity, theDate: String, theStatus: Float) {
        let fetchRequest = NSFetchRequest(entityName: "ActivityProgress")
        fetchRequest.predicate = NSPredicate(format: "activity.name == %@ AND date == %@", theAct.name, theDate)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
        
        do {
            let result = try context.executeFetchRequest(fetchRequest) as! [ActivityProgress]
            if (result.count == 0) {
                let progress = insertProgressData(context, date: theDate, status: theStatus)
                insertProgressActRelation(theAct, theProgress: progress)
                save(context)
            }
            else {
                updateProgressStatus(result[0], status: theStatus)
            }
        }
        catch {
            print(error)
        }
    }
    
    func updateGoalAnswer(theGoal: Goal, answer: String) {
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            theGoal.answer = answer
            save(managedObjectContext)
        }
    }
    
    
    func updateActivityStatus(theAct: Activity, status: Float) {
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            theAct.status = status
            save(managedObjectContext)
        }
    }
    
    func updateProgressStatus(theProgress: ActivityProgress, status: Float) {
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            theProgress.status = status
            save(managedObjectContext)
        }
    }
    
//    func deleteAll() {
//        if let appDel = UIApplication.sharedApplication().delegate as? AppDelegate {
//            let managedObjectContext = appDel.managedObjectContext
//            let coord = appDel.persistentStoreCoordinator
//            let fetchRequest = NSFetchRequest(entityName: "Goal")
//            let deleteRequest = NSBatchDeleteRequest (fetchRequest: fetchRequest)
//            
//            do {
//                try coord.executeRequest (deleteRequest, withContext: managedObjectContext)
//            } catch {
//                print(error)
//            }
//        }
//    }

    func deleteGoal(theGoal: Goal) {
        if let appDel = UIApplication.sharedApplication().delegate as? AppDelegate {
            let managedObjectContext = appDel.managedObjectContext
            managedObjectContext.deleteObject(theGoal)
            save(managedObjectContext)
        }
    }
    
    func deleteActivity(theActivity: Activity) {
        if let appDel = UIApplication.sharedApplication().delegate as? AppDelegate {
            let managedObjectContext = appDel.managedObjectContext
            managedObjectContext.deleteObject(theActivity)
            save(managedObjectContext)
        }
    }
    
    func goalEntityIsEmpty() -> Bool {
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
            let fetchRequest = NSFetchRequest (entityName: "Goal")
            do{
                try managedObjectContext.executeFetchRequest(fetchRequest)
            } catch {
                print(error)
            }
            let count = managedObjectContext.countForFetchRequest(fetchRequest, error: nil)
            if count == 0 {
                return true
            }
            else {
                return false
            }
        }
        return true
    }
    
//    func activityEntityIsEmpty() -> Bool {
//        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext {
//            let fetchRequest = NSFetchRequest (entityName: "Activity")
//            do{
//                try managedObjectContext.executeFetchRequest(fetchRequest)
//            } catch {
//                print(error)
//            }
//            let count = managedObjectContext.countForFetchRequest(fetchRequest, error: nil)
//            if count == 0 {
//                return true
//            }
//            else {
//                return false
//            }
//        }
//        return true
//    }
    
}
