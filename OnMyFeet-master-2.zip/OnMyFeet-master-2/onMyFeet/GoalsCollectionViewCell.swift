//
//  GoalsCollectionViewCell.swift
//  onMyFeet
//
//  Created by apple on 16/2/22.
//  Copyright © 2016年 OnMyFeet Group. All rights reserved.
//

import UIKit

class GoalsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var CheckView: UIImageView!
    @IBOutlet weak var GoalPicture: UIImageView!
}
