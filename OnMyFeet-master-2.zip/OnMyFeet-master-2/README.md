# OnMyFeet

OnMyFeet is an iPhone app that help people recover from injury and regain their confidence
● It enhances patients’ engagement to improve their motivation and effort
● Its main features including the guided-goal setting interviews and frequent self-reporting feedback can improve patients’ rehab participation
● The functions of activity measurement and intensity tracking through wearable can help therapists monitor the progress and further give
instructions
